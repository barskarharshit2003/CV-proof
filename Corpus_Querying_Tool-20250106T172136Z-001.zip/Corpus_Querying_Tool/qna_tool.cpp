#include <assert.h>
#include <sstream>
#include "qna_tool.h"

using namespace std;

class Score_Node{
    public:
        string word;
        float word_score;
    
    Score_Node(){
        word="";
        word_score=0;
    }
    
    Score_Node(string word, float word_score){
        this->word=word;
        this->word_score=word_score;
    }
};

class Heap_Node{
    public:
        int paragraph_no;
        int page_no;
        int book_no;
        float score;
    Heap_Node(){
        paragraph_no=0;
        page_no=0;
        book_no=0;
        score=0;
    }
    
    Heap_Node(int paragraph_no,int page_no,int book_no,float score){
        this->paragraph_no=paragraph_no;
        this->page_no=page_no;
        this->book_no=book_no;
        this->score=score;
    }
};

class Max_Heap{
    private:
        int size=0;
        vector<Heap_Node> Heap_vector;

    public:
        void insert(Heap_Node aux){
            Heap_vector.push_back(aux);
            int idx;
            idx=size;
            while(idx>0 && aux.score>(Heap_vector[(idx-1)/2]).score){
                Heap_vector[idx]=Heap_vector[(idx-1)/2];
                Heap_vector[(idx-1)/2]=aux;
                idx=(idx-1)/2;
            }
            size++;
        }

        Heap_Node* get_top(){
            return &Heap_vector[0];
        }

        void Delete(){
            Heap_vector[0]=Heap_vector[size-1];
            size--;
            int idx=0;
            int ptr=0;
            while(idx<=size){
            if(idx*2+1<size&&Heap_vector[idx].score<Heap_vector[2*idx+1].score) ptr=idx*2+1;
            if(idx*2+2<size&&Heap_vector[ptr].score<Heap_vector[2*idx+2].score) ptr=idx*2+2;
            if(ptr==idx) break;
            else {
                Heap_Node aux;
                aux=Heap_vector[idx];
                Heap_vector[idx]=Heap_vector[ptr];
                Heap_vector[ptr]=aux;
                idx=ptr;
            }
            }
        }
};

QNA_tool::QNA_tool(){
    // Implement your function here
    storage=new storage_node();
    occurence_tree=new trie();
    //access the csv file
    ifstream my_file;
        my_file.open("unigram_freq.csv");
        
        // now insert all the words existing in the csv file in the tries thar we made
        while(my_file.good()){
            string s1;
            string s2;
            getline(my_file,s1,',');
            getline(my_file,s2,'\n');
            if(s2[0]>57){
                continue;
            }
            if(s1.empty()){
                continue;
            }
            float temp;
            temp=stof(s2);
            occurence_tree->insert_general(s1,temp); //temp is float
        }

        my_file.close();
    }

QNA_tool::~QNA_tool(){
    // Implement your function here
    delete storage;
    delete occurence_tree;
}

void QNA_tool::insert_sentence(int book_code, int page, int paragraph, int sentence_no, string sentence){
    // Implement your function here
        
        //   int a = storage->paragraph.back();
     if(storage->paragraph.size() == 0 ) {
          storage->book_code.push_back(book_code);
        storage->page.push_back(page);
        storage->paragraph.push_back(paragraph);
        Dict* store = new Dict();
        store->insert_sentence(0,0,0,0,sentence);
        storage->sentence.push_back(store);
     }else if(storage->paragraph.back()!= paragraph ){      // emptry vector ??
        
        storage->book_code.push_back(book_code);
        storage->page.push_back(page);
        storage->paragraph.push_back(paragraph);
        Dict* store=new Dict();
        store->insert_sentence(0,0,0,0,sentence);
        storage->sentence.push_back(store);
    }else {
     
        storage->sentence[storage->sentence.size()-1]->insert_sentence(0,0,0,0,sentence);
          
    }
   
    occurence_tree->insert_sentence(sentence);
    return;
}

Node* QNA_tool::get_top_k_para(string question, int k) {
    // Implement your function here
    //pre-processing the query
        string processed_question;
        for(auto i:question){
            processed_question=processed_question+(char)tolower(i);
        }

        //storing each word of the query in a vector
        vector<Score_Node> words_vector;
        string step_word;
        for(int i=0;i<processed_question.size();i++){
            if(processed_question[i]=='['||processed_question[i]==']'||processed_question[i]=='('||processed_question[i]==')'||processed_question[i]=='.'||processed_question[i]==','||processed_question[i]==':'||processed_question[i]==';'||processed_question[i]=='?'||processed_question[i]=='!'||processed_question[i]=='@'||processed_question[i]=='-'||processed_question[i]==39||processed_question[i]=='"'||processed_question[i]==' '){
                if(step_word.size()!=0){
                    Score_Node aux;
                    aux.word=step_word;
                    float specific_frequency=occurence_tree->get_count_corpus(step_word);  //get from csv file
                    float general_frequency=occurence_tree->get_count_general(step_word);  //get from trie
                    aux.word_score=(specific_frequency+1)/(general_frequency+1);
                    words_vector.push_back(aux);
                    step_word.clear();
                    continue;
                }
                step_word.clear();
                continue;
            }
            else{
                step_word=step_word+processed_question[i];
            }
        }
        if(step_word.size()!=0){
            Score_Node aux;
            aux.word=step_word;
            float specific_frequency=occurence_tree->get_count_corpus(step_word);  //get from csv file
            float general_frequency=occurence_tree->get_count_general(step_word);  //get from trie
            aux.word_score=(specific_frequency+1)/(general_frequency+1);
            words_vector.push_back(aux);
            step_word.clear();
        }

        //initiallising a Heap
    Max_Heap* Paragraph_Heap=new Max_Heap();

        for(int j=0;j<storage->sentence.size();j++){  //storage->sentences.size()
            float paragraph_score=0;
            for(int i=0;i<words_vector.size();i++){
                paragraph_score=paragraph_score+(storage->sentence[j]->get_word_count(words_vector[i].word)*words_vector[i].word_score); //get word frequency in paragraph from AVL tree : storage->sentence->get_word_count(current_word)
            }
            Heap_Node aux(storage->paragraph[j],storage->page[j],storage->book_code[j], paragraph_score);
            //insert this in MaxHeap storing score of all paragraphs
            Paragraph_Heap->insert(aux);
        }
            //Creating the linked list
                Node* head;
                head=NULL;
                Node* ptr;
                ptr=head;
            for(int ctr=0;ctr<k;ctr++){
                    if(head==NULL){
                        Heap_Node* temp=Paragraph_Heap->get_top();
                        head=new Node(temp->book_no,temp->page_no,temp->paragraph_no,0,0);
                        Paragraph_Heap->Delete();
                        ptr=head;
                    }else{
                        Node* aux;
                        Heap_Node* temp=Paragraph_Heap->get_top();
                        aux=new Node(temp->book_no,temp->page_no,temp->paragraph_no,0,0);
                        ptr->right=aux;
                        aux->left=ptr;
                        ptr=aux;
                        ptr->right=NULL;    
                        Paragraph_Heap->Delete();
                    }
                }
                delete Paragraph_Heap;

            return head;
}


Node* QNA_tool::get_top_k_comp(string question, int k) {
    // Implement your function here
    //pre-processing the query
        string processed_question;
        for(auto i:question){
            processed_question=processed_question+(char)tolower(i);
        }

        //storing each word of the query in a vector
        vector<Score_Node> words_vector;
        string step_word;
        for(int i=0;i<processed_question.size();i++){
            if(processed_question[i]=='['||processed_question[i]==']'||processed_question[i]=='('||processed_question[i]==')'||processed_question[i]=='.'||processed_question[i]==','||processed_question[i]==':'||processed_question[i]==';'||processed_question[i]=='?'||processed_question[i]=='!'||processed_question[i]=='@'||processed_question[i]=='-'||processed_question[i]==39||processed_question[i]=='"'||processed_question[i]==' '){
                if(step_word.size()!=0){
                    Score_Node aux;
                    aux.word=step_word;
                    float specific_frequency=occurence_tree->get_count_corpus(step_word);  //get from csv file
                    float general_frequency=occurence_tree->get_count_general(step_word);  //get from trie
                    if(step_word.size()<3||(step_word.size()<4 && general_frequency>155733641.01)){
                        aux.word_score=0;
                        continue;
                    } else {
                        aux.word_score=(specific_frequency+1)/(general_frequency+1);
                        words_vector.push_back(aux);
                        step_word.clear();
                        continue;
                    }
                }
                step_word.clear();
                continue;
            }
            else{
                step_word=step_word+processed_question[i];
            }
        }
        if(step_word.size()!=0){
            Score_Node aux;
            aux.word=step_word;
            float specific_frequency=occurence_tree->get_count_corpus(step_word);  //get from csv file
            float general_frequency=occurence_tree->get_count_general(step_word);  //get from trie
            aux.word_score=(specific_frequency+1)/(general_frequency+1);
            words_vector.push_back(aux);
            step_word.clear();
        }

        //initiallising a Heap
    Max_Heap* Paragraph_Heap=new Max_Heap();

        for(int j=0;j<storage->sentence.size();j++){  //storage->sentences.size()
            float paragraph_score=0;
            for(int i=0;i<words_vector.size();i++){
                paragraph_score=paragraph_score+(storage->sentence[j]->get_word_count(words_vector[i].word)*words_vector[i].word_score); //get word frequency in paragraph from AVL tree : storage->sentence->get_word_count(current_word)
            }
            Heap_Node aux(storage->paragraph[j],storage->page[j],storage->book_code[j], paragraph_score);
            //insert this in MaxHeap storing score of all paragraphs
            Paragraph_Heap->insert(aux);
        }
            //Creating the linked list
                Node* head;
                head=NULL;
                Node* ptr;
                ptr=head;
            for(int ctr=0;ctr<k;ctr++){
                    if(head==NULL){
                        Heap_Node* temp=Paragraph_Heap->get_top();
                        head=new Node(temp->book_no,temp->page_no,temp->paragraph_no,0,0);
                        Paragraph_Heap->Delete();
                        ptr=head;
                    }else{
                        Node* aux;
                        Heap_Node* temp=Paragraph_Heap->get_top();
                        aux=new Node(temp->book_no,temp->page_no,temp->paragraph_no,0,0);
                        ptr->right=aux;
                        aux->left=ptr;
                        ptr=aux;
                        ptr->right=NULL;
                        Paragraph_Heap->Delete();
                    }
                }
                delete Paragraph_Heap;

            return head;
}

void QNA_tool::query(string question, string filename){
    // Implement your function here
//    std::cout << "Q: " << question << std::endl;
//    std::cout << "A: " << "Studying COL106 :)" << std::endl;
    Node* l=get_top_k_comp(question, 4);
    query_llm(filename, l, 4, "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", question);
    return;
}

std::string QNA_tool::get_paragraph(int book_code, int page, int paragraph){

    cout << "Book_code: " << book_code << " Page: " << page << " Paragraph: " << paragraph << endl;
    
    std::string filename = "mahatma-gandhi-collected-works-volume-";
    filename += to_string(book_code);
    filename += ".txt";

    std::ifstream inputFile(filename);

    std::string tuple;
    std::string sentence;

    if (!inputFile.is_open()) {
        std::cerr << "Error: Unable to open the input file " << filename << "." << std::endl;
        exit(1);
    }

    std::string res = "";

    while (std::getline(inputFile, tuple, ')') && std::getline(inputFile, sentence)) {
        // Get a line in the sentence
        tuple += ')';

        int metadata[5];
        std::istringstream iss(tuple);

        // Temporary variables for parsing
        std::string token;

        // Ignore the first character (the opening parenthesis)
        iss.ignore(1);

        // Parse and convert the elements to integers
        int idx = 0;
        while (std::getline(iss, token, ',')) {
            // Trim leading and trailing white spaces
            size_t start = token.find_first_not_of(" ");
            size_t end = token.find_last_not_of(" ");
            if (start != std::string::npos && end != std::string::npos) {
                token = token.substr(start, end - start + 1);
            }
            
            // Check if the element is a number or a string
            if (token[0] == '\'') {
                // Remove the single quotes and convert to integer
                int num = std::stoi(token.substr(1, token.length() - 2));
                metadata[idx] = num;
            } else {
                // Convert the element to integer
                int num = std::stoi(token);
                metadata[idx] = num;
            }
            idx++;
        }

        if(
            (metadata[0] == book_code) &&
            (metadata[1] == page) &&
            (metadata[2] == paragraph)
        ){
            res += sentence;
        }
    }

    inputFile.close();
    return res;
}

void QNA_tool::query_llm(string filename, Node* root, int k, string API_KEY, string question){

    // first write the k paragraphs into different files

    Node* traverse = root;
    int num_paragraph = 0;

    while(num_paragraph < k){
        assert(traverse != nullptr);
        string p_file = "paragraph_";
        p_file += to_string(num_paragraph);
        p_file += ".txt";
        // delete the file if it exists
        remove(p_file.c_str());
        ofstream outfile(p_file);
        string paragraph = get_paragraph(traverse->book_code, traverse->page, traverse->paragraph);
        assert(paragraph != "$I$N$V$A$L$I$D$");
        outfile << paragraph;
        outfile.close();
        traverse = traverse->right;
        num_paragraph++;
    }

    // write the query to query.txt
    ofstream outfile("query.txt");
    outfile << "These are the excerpts from Mahatma Gandhi's books. \nOn the basis of this, ";
    outfile << question;
    outfile<<  "while giving the answer please ensure to give any answer you are able to interpret and not give any vague answers like it is not clear or mentioned";
    // You can add anything here - show all your creativity and skills of using ChatGPT
    outfile.close();
 
    // you do not need to necessarily provide k paragraphs - can configure yourself

    // python3 <filename> API_KEY num_paragraphs query.txt
    string command = "python3 ";
    command += filename;
    command += " ";
    command += API_KEY;
    command += " ";
    command += to_string(k);
    command += " ";
    command += "query.txt";

    system(command.c_str());
    return;
}
//int main(){
//    QNA_tool Q ;
//    
//     Q.insert_sentence(1,1,3,1,"I am feeling lucky");
//     Q.insert_sentence(1,1,4,1,"Ok Its about her");
//       Q.insert_sentence(1,1,5,1,"Ok that not much");
//          Q.insert_sentence(1,1,5,2,"its not okay go");
//          cout<<"yo";
//   Node* Nd =  Q.get_top_k_para("OK",2);
//       cout<<Nd->paragraph;
//    return 0;
//}
