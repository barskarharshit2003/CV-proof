import numpy as np
I=list(map(float,input().split()))
A=[[I[0],I[1]],[I[2],I[3]]]
pi=[*map(float,input().split())]
T=int(input())
Y=[0]
for i in range(T):
     Y.append(float(input()))
A_0=[A[0][0],A[0][1]]
A_1=[A[1][0],A[1][1]]

    
alpha_0=[0 for i in range(T+1)]
alpha_1=[0 for i in range(T+1)]

beta_0=[0 for i in range(T+1)]
beta_1=[0 for i in range(T+1)]

gamma_0=[0 for i in range(T+1)]
gamma_1=[0 for i in range(T+1)]
chi_00=[0 for i in range(T+1)]
chi_01=[0 for i in range(T+1)]
chi_10=[0 for i in range(T+1)]
chi_11=[0 for i in range(T+1)]

mu=[0,0]
sigma_square=[1,1]


#Helper Functions 
def pdf(i,t):
    return 1 / np.sqrt(2 * np.pi * sigma_square[i]) * np.exp(-0.5 * ((t - mu[i]) ** 2) / sigma_square[i])

def summation( upper_limit , list ):
    sum=0
    for k in range (1,upper_limit+1):
        sum=sum+list[k]
    return sum
        
def summation_product(upper_limit,list1,list2):
    sum=0
    for k in range(1,upper_limit+1):
        sum=sum+((list1[k])*(list2[k]))
    return sum


#Generation Functions
def generate_alpha_0(t):
    if t==0:
        alpha_0[1]=pi[0]*pdf(0,Y[1])
    else:
        alpha_0[t+1]=pdf(0,Y[t+1])*(((alpha_0[t])*(A_0[0]))+((alpha_1[t])*(A_1[0])))
        
def generate_alpha_1(t):
    if t==0:
        alpha_1[1]=pi[1]*pdf(1,Y[1])
    else:
        alpha_1[t+1]=pdf(1,Y[t+1])*(((alpha_0[t])*(A_0[1]))+((alpha_1[t])*(A_1[1])))
        
def generate_beta_0(t):
    if t==T:
        beta_0[T]=1
    else:
        beta_0[t]=((beta_0[t+1])*(A_0[0])*pdf(0,Y[t+1]))+((beta_1[t+1])*(A_0[1])*pdf(1,Y[t+1]))    
        
def generate_beta_1(t):
    if t==T:
        beta_1[T]=1
    else:
        beta_1[t]=((beta_0[t+1])*(A_1[0])*pdf(0,Y[t+1]))+((beta_1[t+1])*(A_1[1])*pdf(1,Y[t+1]))       
        
def generate_gamma_0(t):
    gamma_0[t]=((alpha_0[t])*(beta_0[t]))/(((alpha_0[t])*(beta_0[t]))+((alpha_1[t])*(beta_1[t])))

def generate_gamma_1(t):
    gamma_1[t]=((alpha_1[t])*(beta_1[t]))/(((alpha_0[t])*(beta_0[t]))+((alpha_1[t])*(beta_1[t])))

def generate_chi_00(t):
    P=(((alpha_0[t])*(A_0[0])*(beta_0[t+1])*(pdf(0,Y[t+1]))))+(((alpha_0[t])*(A_0[1])*(beta_1[t+1])*(pdf(1,Y[t+1]))))+(((alpha_1[t])*(A_1[0])*(beta_0[t+1])*(pdf(0,Y[t+1]))))+(((alpha_1[t])*(A_1[1])*(beta_1[t+1])*(pdf(1,Y[t+1]))))
    chi_00[t]=(((alpha_0[t])*(A_0[0])*(beta_0[t+1])*(pdf(0,Y[t+1]))))/P
    
def generate_chi_01(t):
    P=(((alpha_0[t])*(A_0[0])*(beta_0[t+1])*(pdf(0,Y[t+1]))))+(((alpha_0[t])*(A_0[1])*(beta_1[t+1])*(pdf(1,Y[t+1]))))+(((alpha_1[t])*(A_1[0])*(beta_0[t+1])*(pdf(0,Y[t+1]))))+(((alpha_1[t])*(A_1[1])*(beta_1[t+1])*(pdf(1,Y[t+1]))))
    
    chi_01[t]=(((alpha_0[t])*(A_0[1])*(beta_1[t+1])*(pdf(1,Y[t+1]))))/P
def generate_chi_10(t):
    P=(((alpha_0[t])*(A_0[0])*(beta_0[t+1])*(pdf(0,Y[t+1]))))+(((alpha_0[t])*(A_0[1])*(beta_1[t+1])*(pdf(1,Y[t+1]))))+(((alpha_1[t])*(A_1[0])*(beta_0[t+1])*(pdf(0,Y[t+1]))))+(((alpha_1[t])*(A_1[1])*(beta_1[t+1])*(pdf(1,Y[t+1]))))
    
    chi_10[t]=(((alpha_1[t])*(A_1[0])*(beta_0[t+1])*(pdf(0,Y[t+1]))))/P
    
def generate_chi_11(t):
    P=(((alpha_0[t])*(A_0[0])*(beta_0[t+1])*(pdf(0,Y[t+1]))))+(((alpha_0[t])*(A_0[1])*(beta_1[t+1])*(pdf(1,Y[t+1]))))+(((alpha_1[t])*(A_1[0])*(beta_0[t+1])*(pdf(0,Y[t+1]))))+(((alpha_1[t])*(A_1[1])*(beta_1[t+1])*(pdf(1,Y[t+1]))))
    
    chi_11[t]=(((alpha_1[t])*(A_1[1])*(beta_1[t+1])*(pdf(1,Y[t+1]))))/P


for iteration in range(0,500):
    for time in range(0,T):
        generate_alpha_0(time)
        generate_alpha_1(time)
    for time in range(T,0,-1):
        generate_beta_0(time)
        generate_beta_1(time)
    for time in range(1,T+1):
        generate_gamma_0(time)
        generate_gamma_1(time)
    for time in range(1,T):
        generate_chi_00(time)
        generate_chi_01(time)
        generate_chi_10(time)
        generate_chi_11(time)
        
    pi[0]=gamma_0[1]
    pi[1]=gamma_1[1]
    
    A_0[0]=(summation(T-1,chi_00))/(summation(T-1,gamma_0))
    A_0[1]=summation(T-1,chi_01)/summation(T-1,gamma_0)
    A_1[0]=summation(T-1,chi_10)/summation(T-1,gamma_1)
    A_1[1]=summation(T-1,chi_11)/summation(T-1,gamma_1)
        
    mu[0]=summation_product(T,Y,gamma_0)/summation(T,gamma_0)
    mu[1]=summation_product(T,Y,gamma_1)/summation(T,gamma_1)
    
    
    num_sum_0=0
    for r in range(1,T+1):
        num_sum_0=num_sum_0+(((Y[r]-mu[0])*(Y[r]-mu[0]))*gamma_0[r])
    sigma_square[0]=num_sum_0/summation(T,gamma_0)

    num_sum_1=0
    for r in range(1,T+1):
        num_sum_1=num_sum_1+(((Y[r]-mu[1])*(Y[r]-mu[1]))*gamma_1[r])
    sigma_square[1]=num_sum_1/summation(T,gamma_1)
    
    
    continue

#Final Output Production
if mu[0]>mu[1]:
    for time in range(1,T+1):
        if gamma_0[time]>gamma_1[time]:
            print("Bull")
        else:
            print("Bear")
else:
    for time in range(1,T+1):
        if gamma_0[time]>gamma_1[time]:
            print("Bear")
        else:
            print("Bull")


#Check all Functions 
#Test the method 
#Integrate the Code